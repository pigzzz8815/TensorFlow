
Raccoon - v38 416x416-resize
==============================

This dataset was exported via roboflow.ai on June 8, 2021 at 5:30 PM GMT

It includes 196 images.
Raccoons are annotated in Pascal VOC format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


